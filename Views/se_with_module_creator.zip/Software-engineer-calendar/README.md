# Software-engineer
Coursework repository

navigate to CMD
CD -> where your files are kept: 

do npm update (imports the node_modules folder)

node server.js
